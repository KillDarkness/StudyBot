import { type NextRequest, NextResponse } from "next/server"

const GEMINI_API_KEY = process.env.GEMINI_API_KEY
const GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent"

const SYSTEM_PROMPT = `Você é um ChatBot Escolar especializado em "Escrever & Resumir" para estudantes. Suas principais funções são:

🎯 RESUMIR TEXTOS:
- Transforme textos longos em resumos objetivos e organizados
- Use tópicos, listas e estruturas claras
- Mantenha os pontos principais sem perder informações essenciais
- Adapte o nível de detalhamento conforme solicitado

✍️ ESCREVER TEXTOS ACADÊMICOS:
- Ajude com introduções, desenvolvimentos e conclusões
- Crie citações e referências adequadas
- Sugira estruturas para trabalhos escolares
- Desenvolva argumentos e ideias de forma clara

📚 SIMPLIFICAR LINGUAGEM:
- Transforme textos complexos em linguagem acessível
- Explique conceitos difíceis de forma simples
- Use exemplos práticos e analogias
- Mantenha a precisão técnica mas com clareza

DIRETRIZES:
- Seja didático e organizado em suas respostas
- Use formatação clara (tópicos, numeração, etc.)
- Adapte a linguagem ao nível do estudante
- Seja completo mas objetivo
- Sempre mantenha foco educacional
- Lembre-se do contexto da conversa anterior
- Use --- para separar seções quando apropriado

Você é um assistente escolar dedicado a facilitar o aprendizado através da escrita e resumo eficazes.`

export async function POST(request: NextRequest) {
  try {
    const { message, history } = await request.json()

    if (!GEMINI_API_KEY) {
      return NextResponse.json({ error: "API key do Gemini não configurada" }, { status: 500 })
    }

    // Monta o histórico da conversa incluindo o contexto
    const conversationHistory = history.map((msg: any) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.content }],
    }))

    // Detecta se há conteúdo de arquivo na mensagem
    const hasFileContent = message.includes("Conteúdo do arquivo")

    const requestBody = {
      contents: [
        {
          role: "user",
          parts: [{ text: SYSTEM_PROMPT }],
        },
        ...conversationHistory,
        {
          role: "user",
          parts: [{ text: message }],
        },
      ],
      generationConfig: {
        temperature: hasFileContent ? 0.3 : 0.7,
        topK: hasFileContent ? 20 : 40,
        topP: hasFileContent ? 0.8 : 0.95,
        maxOutputTokens: hasFileContent ? 4096 : 2048,
      },
    }

    const response = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
    })

    if (!response.ok) {
      throw new Error(`Erro na API do Gemini: ${response.status}`)
    }

    const data = await response.json()
    const aiResponse = data.candidates?.[0]?.content?.parts?.[0]?.text || "Desculpe, não consegui gerar uma resposta."

    return NextResponse.json({ response: aiResponse })
  } catch (error) {
    console.error("Erro na API:", error)
    return NextResponse.json({ error: "Erro interno do servidor" }, { status: 500 })
  }
}
